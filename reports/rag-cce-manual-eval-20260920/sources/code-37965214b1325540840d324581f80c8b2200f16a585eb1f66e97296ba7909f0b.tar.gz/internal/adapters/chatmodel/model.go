package chatmodel

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/cloudwego/eino/components/model"
	"github.com/cloudwego/eino/schema"
	"go.opentelemetry.io/otel/attribute"

	"hwops/internal/domain"
	"hwops/internal/observability"
)

var ErrUnavailable = errors.New("model unavailable")

type ContextInput struct {
	Question  string                `json:"question"`
	Documents []*schema.Document    `json:"documents"`
	Device    *domain.DeviceContext `json:"device_context,omitempty"`
}

// Replay is an explicitly selected extractive demonstration, never a fallback.
type Replay struct{}

var _ model.BaseChatModel = (*Replay)(nil)

func (m *Replay) Generate(ctx context.Context, input []*schema.Message, _ ...model.Option) (*schema.Message, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if len(input) == 0 {
		return nil, errors.New("missing input")
	}
	var payload ContextInput
	if err := json.Unmarshal([]byte(input[len(input)-1].Content), &payload); err != nil {
		return nil, err
	}
	if len(payload.Documents) == 0 {
		return nil, errors.New("missing documents")
	}
	doc := payload.Documents[0]
	content, err := json.Marshal(domain.Draft{Claims: []domain.Claim{{
		Text: "【演示摘录，非模型诊断】" + doc.Content, FragmentIDs: []string{doc.ID},
	}}})
	if err != nil {
		return nil, err
	}
	return schema.AssistantMessage(string(content), nil), nil
}

func (m *Replay) Stream(ctx context.Context, in []*schema.Message, opts ...model.Option) (*schema.StreamReader[*schema.Message], error) {
	out, err := m.Generate(ctx, in, opts...)
	if err != nil {
		return nil, err
	}
	return schema.StreamReaderFromArray([]*schema.Message{out}), nil
}

type Unconfigured struct{}

func (*Unconfigured) Generate(context.Context, []*schema.Message, ...model.Option) (*schema.Message, error) {
	return nil, ErrUnavailable
}

func (*Unconfigured) Stream(context.Context, []*schema.Message, ...model.Option) (*schema.StreamReader[*schema.Message], error) {
	return nil, ErrUnavailable
}

// OpenAI calls an explicitly configured chat/completions endpoint.
type OpenAI struct {
	endpoint string
	name     string
	key      string
	client   *http.Client
}

var _ model.BaseChatModel = (*OpenAI)(nil)

func NewOpenAI(endpoint, name, key string) (*OpenAI, error) {
	u, err := url.Parse(endpoint)
	if err != nil || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" ||
		(u.Scheme != "http" && u.Scheme != "https") || name == "" {
		return nil, errors.New("invalid model endpoint or model name")
	}
	return &OpenAI{endpoint: endpoint, name: name, key: key, client: &http.Client{
		Timeout: 30 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}}, nil
}

func (m *OpenAI) Generate(ctx context.Context, input []*schema.Message, _ ...model.Option) (messageOut *schema.Message, callErr error) {
	ctx, span := observability.Start(ctx, "chat.generate", "LLM", input)
	span.SetAttributes(attribute.String("llm.model_name", m.name))
	if strings.HasPrefix(m.name, "deepseek-") {
		span.SetAttributes(attribute.String("llm.provider", "deepseek"), attribute.String("llm.system", "deepseek"))
	}
	defer func() { observability.End(span, messageOut, callErr) }()
	type message struct {
		Role    string `json:"role"`
		Content string `json:"content"`
	}
	messages := make([]message, 0, len(input))
	for _, item := range input {
		messages = append(messages, message{Role: string(item.Role), Content: item.Content})
	}
	var thinking map[string]string
	if strings.HasPrefix(m.name, "deepseek-") {
		thinking = map[string]string{"type": "disabled"}
	}
	body, err := json.Marshal(struct {
		Model    string    `json:"model"`
		Messages []message `json:"messages"`
		Stream   bool      `json:"stream"`
		Thinking map[string]string `json:"thinking,omitempty"`
	}{m.name, messages, false, thinking})
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, m.endpoint, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	if m.key != "" {
		req.Header.Set("Authorization", "Bearer "+m.key)
	}
	response, err := m.client.Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		return nil, ErrUnavailable
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("%w: HTTP %d", ErrUnavailable, response.StatusCode)
	}
	raw, err := io.ReadAll(io.LimitReader(response.Body, 1024*1024+1))
	if ctx.Err() != nil {
		return nil, ctx.Err()
	}
	if err != nil || len(raw) > 1024*1024 {
		return nil, fmt.Errorf("%w: unreadable response", ErrUnavailable)
	}
	var result struct {
		Usage *schema.TokenUsage `json:"usage"`
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
		} `json:"choices"`
	}
	if err := json.Unmarshal(raw, &result); err != nil || len(result.Choices) == 0 ||
		strings.TrimSpace(result.Choices[0].Message.Content) == "" {
		return nil, fmt.Errorf("%w: invalid response", ErrUnavailable)
	}
	out := schema.AssistantMessage(result.Choices[0].Message.Content, nil)
	out.ResponseMeta = &schema.ResponseMeta{Usage: result.Usage}
	if result.Usage != nil {
		span.SetAttributes(attribute.Int("llm.token_count.prompt", result.Usage.PromptTokens),
			attribute.Int("llm.token_count.completion", result.Usage.CompletionTokens),
			attribute.Int("llm.token_count.total", result.Usage.TotalTokens))
	}
	return out, nil
}

func (m *OpenAI) Stream(ctx context.Context, in []*schema.Message, opts ...model.Option) (*schema.StreamReader[*schema.Message], error) {
	// QA-01 validates a complete answer before exposing it to the client.
	out, err := m.Generate(ctx, in, opts...)
	if err != nil {
		return nil, err
	}
	return schema.StreamReaderFromArray([]*schema.Message{out}), nil
}
