package knowledge

import (
	"strings"
	"testing"

	"hwops/internal/domain"
)

func TestNewRevisionBoundsLargeSections(t *testing.T) {
	longLine := strings.Repeat("节点参数", maxFragmentBytes)
	revision, err := NewRevision(domain.RevisionInput{
		Title:         "大文档",
		Source:        "https://example.test/manual",
		Content:       "# 一级\n\n" + strings.Repeat("普通段落\n", 3000) + "\n## 二级\n" + longLine,
		Applicability: domain.Applicability{Scope: "GENERAL"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(revision.Fragments) < 3 {
		t.Fatalf("expected bounded fragments, got %d", len(revision.Fragments))
	}
	for _, fragment := range revision.Fragments {
		if len(fragment.Content) > maxFragmentBytes {
			t.Fatalf("fragment %q has %d bytes", fragment.Section, len(fragment.Content))
		}
		if fragment.StartLine < 1 || fragment.EndLine < fragment.StartLine {
			t.Fatalf("invalid line range: %+v", fragment)
		}
	}
}

func TestNewRevisionKeepsShortSectionsUnchanged(t *testing.T) {
	revision, err := NewRevision(domain.RevisionInput{
		Title:         "短文档",
		Source:        "https://example.test/manual",
		Content:       "# 标题\n第一段\n第二段\n## 操作\n执行检查。",
		Applicability: domain.Applicability{Scope: "GENERAL"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(revision.Fragments) != 2 {
		t.Fatalf("expected 2 fragments, got %d", len(revision.Fragments))
	}
	if revision.Fragments[0].Section != "标题" || revision.Fragments[0].Content != "第一段\n第二段" {
		t.Fatalf("unexpected first fragment: %+v", revision.Fragments[0])
	}
	if revision.Fragments[1].Section != "操作" || revision.Fragments[1].Content != "执行检查。" {
		t.Fatalf("unexpected second fragment: %+v", revision.Fragments[1])
	}
}
