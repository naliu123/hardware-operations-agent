package knowledge

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/cloudwego/eino/components/retriever"
	"github.com/cloudwego/eino/schema"

	"hwops/internal/domain"
)

const maxFragmentBytes = 12 * 1024

type textChunk struct {
	content            string
	startLine, endLine int
}

func splitFragment(content string, startLine, maxBytes int) []textChunk {
	lines := strings.Split(content, "\n")
	var chunks []textChunk
	var current []string
	currentBytes, chunkStart := 0, startLine
	flush := func(endLine int) {
		text := strings.TrimSpace(strings.Join(current, "\n"))
		if text != "" {
			chunks = append(chunks, textChunk{content: text, startLine: chunkStart, endLine: endLine})
		}
		current, currentBytes = nil, 0
	}
	for offset, line := range lines {
		lineNumber := startLine + offset
		added := len(line)
		if len(current) > 0 {
			added++
		}
		if len(current) > 0 && currentBytes+added > maxBytes {
			flush(lineNumber - 1)
			chunkStart = lineNumber
		}
		for len(line) > maxBytes {
			cut := maxBytes
			for cut > 0 && !utf8.RuneStart(line[cut]) {
				cut--
			}
			if cut == 0 {
				cut = maxBytes
			}
			current = []string{line[:cut]}
			currentBytes = cut
			flush(lineNumber)
			line = line[cut:]
			chunkStart = lineNumber
		}
		if len(current) == 0 {
			chunkStart = lineNumber
		}
		current = append(current, line)
		currentBytes += len(line)
		if len(current) > 1 {
			currentBytes++
		}
	}
	flush(startLine + len(lines) - 1)
	return chunks
}

func NewRevision(in domain.RevisionInput) (domain.Revision, error) {
	if strings.TrimSpace(in.Title) == "" || strings.TrimSpace(in.Source) == "" ||
		strings.TrimSpace(in.Content) == "" || len(in.Content) > 256*1024 {
		return domain.Revision{}, fmt.Errorf("%w: title, source and text content are required (256 KiB max)", domain.ErrInvalid)
	}
	if in.Applicability.Scope != "GENERAL" && in.Applicability.Scope != "DEVICE" {
		return domain.Revision{}, fmt.Errorf("%w: applicability.scope must be GENERAL or DEVICE", domain.ErrInvalid)
	}
	if in.Applicability.Scope == "GENERAL" && (in.Applicability.Model != "" || in.Applicability.Firmware != "" ||
		in.Applicability.Driver != "" || in.Applicability.HardwareRevision != "" || in.Applicability.PolicyID != "" ||
		in.Applicability.FirmwareRange != nil || in.Applicability.DriverRange != nil) {
		return domain.Revision{}, fmt.Errorf("%w: GENERAL cannot restrict model or versions", domain.ErrInvalid)
	}
	if in.Applicability.Scope == "DEVICE" && in.Applicability.Model == "" {
		return domain.Revision{}, fmt.Errorf("%w: DEVICE requires model", domain.ErrInvalid)
	}
	for _, requirement := range []struct {
		exact  string
		bounds *domain.VersionRange
	}{
		{in.Applicability.Firmware, in.Applicability.FirmwareRange},
		{in.Applicability.Driver, in.Applicability.DriverRange},
	} {
		if requirement.bounds != nil && (requirement.exact != "" || requirement.bounds.Min == "" || requirement.bounds.Max == "") {
			return domain.Revision{}, fmt.Errorf("%w: a closed version range requires min/max and cannot coexist with an exact version", domain.ErrInvalid)
		}
	}
	r := domain.Revision{
		SchemaVersion: 1, ID: rand.Text(), DocumentID: rand.Text(),
		Title: in.Title, Source: in.Source, Content: in.Content,
		Applicability: in.Applicability, Status: "DRAFT", CreatedAt: time.Now().UTC(),
	}
	section, start := "正文", 1
	var body []string
	flush := func(end int) {
		content := strings.TrimSpace(strings.Join(body, "\n"))
		if content != "" {
			chunks := splitFragment(content, start, maxFragmentBytes)
			for i, chunk := range chunks {
				chunkSection := section
				if len(chunks) > 1 {
					chunkSection = fmt.Sprintf("%s（第%d部分）", section, i+1)
				}
				r.Fragments = append(r.Fragments, domain.Fragment{
					ID: rand.Text(), RevisionID: r.ID, Section: chunkSection,
					StartLine: chunk.startLine, EndLine: chunk.endLine, Content: chunk.content,
					ContentHash: fmt.Sprintf("%x", sha256.Sum256([]byte(chunk.content))),
				})
			}
		}
		body = nil
	}
	lines := strings.Split(strings.ReplaceAll(in.Content, "\r\n", "\n"), "\n")
	fenced := false
	for i, line := range lines {
		if strings.HasPrefix(strings.TrimSpace(line), "```") {
			fenced = !fenced
		}
		if !fenced && strings.HasPrefix(line, "#") && strings.Contains(line, " ") {
			flush(i)
			section = strings.TrimSpace(strings.TrimLeft(line, "#"))
			start = i + 2
		} else {
			body = append(body, line)
		}
	}
	flush(len(lines))
	if len(r.Fragments) == 0 {
		return domain.Revision{}, fmt.Errorf("%w: no text fragments", domain.ErrInvalid)
	}
	return r, nil
}

// LocalRetriever is a lexical baseline. Hybrid recall is delivered by QA-03.
// Applicability filtering and the final context budget are applied by the graph.
type LocalRetriever struct {
	Store domain.Repository
}

var _ retriever.Retriever = (*LocalRetriever)(nil)

func terms(text string) map[string]bool {
	set := map[string]bool{}
	var run []rune
	flush := func() {
		if len(run) > 0 {
			set[string(run)] = true
		}
		for i := 0; i+1 < len(run); i++ {
			set[string(run[i:i+2])] = true
		}
		run = nil
	}
	for _, r := range strings.ToLower(text) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			run = append(run, r)
		} else {
			flush()
		}
	}
	flush()
	return set
}

func (r *LocalRetriever) Retrieve(ctx context.Context, query string, _ ...retriever.Option) ([]*schema.Document, error) {
	revisions, err := r.Store.ListPublished(ctx)
	if err != nil {
		return nil, err
	}
	type candidate struct {
		doc   *schema.Document
		score int
	}
	var matches []candidate
	q := terms(query)
	for _, revision := range revisions {
		for _, fragment := range revision.Fragments {
			score := 0
			for term := range terms(revision.Title + " " + fragment.Section + " " + fragment.Content) {
				if q[term] {
					score++
				}
			}
			if score > 0 {
				matches = append(matches, candidate{doc: &schema.Document{
					ID: fragment.ID, Content: fragment.Content,
					MetaData: map[string]any{"revision_id": revision.ID},
				}, score: score})
			}
		}
	}
	sort.Slice(matches, func(i, j int) bool {
		if matches[i].score == matches[j].score {
			return matches[i].doc.ID < matches[j].doc.ID
		}
		return matches[i].score > matches[j].score
	})
	var docs []*schema.Document
	for _, m := range matches {
		docs = append(docs, m.doc)
	}
	return docs, nil
}
