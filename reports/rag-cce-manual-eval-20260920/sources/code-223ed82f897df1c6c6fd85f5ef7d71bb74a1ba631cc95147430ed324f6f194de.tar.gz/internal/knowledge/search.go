package knowledge

import (
	"context"
	"fmt"
	"strings"

	"github.com/cloudwego/eino/components/retriever"
	"github.com/cloudwego/eino/schema"
	"go.opentelemetry.io/otel/attribute"

	"hwops/internal/domain"
	"hwops/internal/observability"
)

type SearchInput struct {
	Query    string `json:"query"`
	DeviceID string `json:"device_id,omitempty"`
	Strategy string `json:"strategy,omitempty"`
	TopK     int    `json:"top_k,omitempty"`
}

type SearchDocument struct {
	domain.Fragment
	Source string  `json:"source"`
	Title  string  `json:"title"`
	Score  float64 `json:"score"`
}

type SearchResult struct {
	Documents []SearchDocument        `json:"documents"`
	Checks    []domain.KnowledgeCheck `json:"applicability_checks"`
	TraceID   string                 `json:"trace_id,omitempty"`
}

func (r SearchResult) EinoDocuments() []*schema.Document {
	docs := make([]*schema.Document, 0, len(r.Documents))
	for _, d := range r.Documents {
		docs = append(docs, &schema.Document{ID: d.ID, Content: d.Content, MetaData: map[string]any{
			"revision_id": d.RevisionID, "section": d.Section, "source": d.Source, "score": d.Score,
		}})
	}
	return docs
}

// Search applies eligibility before backend candidate limits, then verifies each
// hit against the authoritative immutable fragment and current publication.
func Search(ctx context.Context, store domain.Repository, backend retriever.Retriever, in SearchInput, device *domain.DeviceContext) (result SearchResult, err error) {
	ctx, span := observability.Start(ctx, "knowledge.search", "RETRIEVER", in)
	defer func() {
		for i, doc := range result.Documents {
			prefix := fmt.Sprintf("retrieval.documents.%d.document.", i)
			span.SetAttributes(attribute.String(prefix+"id", doc.ID),
				attribute.String(prefix+"content", doc.Content),
				attribute.Float64(prefix+"score", doc.Score),
				attribute.String(prefix+"metadata", observability.JSON(map[string]any{
					"revision_id": doc.RevisionID, "section": doc.Section, "source": doc.Source,
				})))
		}
		observability.End(span, result, err)
	}()
	result = SearchResult{Documents: []SearchDocument{}, Checks: []domain.KnowledgeCheck{}, TraceID: observability.TraceID(ctx)}
	if strings.TrimSpace(in.Query) == "" || len(in.Query) > 16000 || in.TopK < 0 || in.TopK > 8 {
		return result, fmt.Errorf("%w: query required (16 KiB max), top_k must be 1..8", domain.ErrInvalid)
	}
	if in.Strategy != "" && in.Strategy != "bm25" && in.Strategy != "dense" && in.Strategy != "hybrid" {
		return result, fmt.Errorf("%w: unsupported retrieval strategy", domain.ErrInvalid)
	}
	if in.TopK == 0 {
		in.TopK = 5
	}
	revisions, err := store.ListPublished(ctx)
	if err != nil {
		return result, err
	}
	eligible := []string{}
	for _, rev := range revisions {
		check, err := Assess(ctx, store, rev.Applicability, device)
		if err != nil {
			return result, err
		}
		result.Checks = append(result.Checks, domain.KnowledgeCheck{RevisionID: rev.ID, Assessment: check})
		if check.Status == "MATCH" {
			eligible = append(eligible, rev.ID)
		}
	}
	if len(eligible) == 0 {
		return result, nil
	}
	docs, err := backend.Retrieve(ctx, in.Query, retriever.WithTopK(in.TopK),
		retriever.WithDSLInfo(map[string]any{"revision_ids": eligible, "strategy": in.Strategy}))
	if err != nil {
		return result, err
	}
	total := 0
	seen := map[string]bool{}
	for _, doc := range docs {
		id, ok := doc.MetaData["revision_id"].(string)
		if !ok {
			return result, fmt.Errorf("retrieval hit lacks revision identity")
		}
		rev, err := store.GetRevision(ctx, id)
		if err != nil {
			return result, err
		}
		check, err := Assess(ctx, store, rev.Applicability, device)
		if err != nil {
			return result, err
		}
		if rev.Status != "PUBLISHED" || check.Status != "MATCH" {
			continue
		}
		for _, fragment := range rev.Fragments {
			if fragment.ID != doc.ID {
				continue
			}
			if fragment.Content != doc.Content {
				return result, fmt.Errorf("retrieval hit differs from source fragment")
			}
			if !seen[fragment.ID] && len(result.Documents) < in.TopK && total+len(fragment.Content) <= 48*1024 {
				score, _ := doc.MetaData["score"].(float64)
				result.Documents = append(result.Documents, SearchDocument{Fragment: fragment, Source: rev.Source, Title: rev.Title, Score: score})
				total += len(fragment.Content)
				seen[fragment.ID] = true
			}
		}
	}
	return result, nil
}
